package com.example.guessmaster;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class GuessMaster extends AppCompatActivity {
    private TextView entityName;
    private TextView ticketsum;
    private Button guessButton;
    private EditText userIn;
    private Button btnclearContent;
    private ImageView entityImage;
    String answer;

    private int numberOfEntities;
    private Entity[] entities;
    private int tickets;
    String entName;
    int entityId = 0;

    Politician trudeau = new Politician("Justin Trudeau", new Date("December", 25,1971), "Male", "Liberal",0.25);
    Singer dion = new Singer("Celine Dion", new Date("March", 30, 1968), "Female","La voix du bon Dieu", new Date("November", 6, 1981),0.5);
    Person myCreator = new Person("My Creator", new Date("January", 1, 2000), "Male", 1.0);
    Country usa = new Country("United States", new Date("July", 4, 1776), "Washington D.C.",0.1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        guessButton = (Button)findViewById(R.id.btnGuess);
        btnclearContent = (Button)findViewById(R.id.btnClear);
        userIn = (EditText)findViewById(R.id.guessinput);
        ticketsum = (TextView)findViewById(R.id.ticket);
        entityName = (TextView)findViewById(R.id.entityName);
        entityImage = (ImageView)findViewById(R.id.entityImage);

        addEntity(trudeau);
        addEntity(dion);
        addEntity(myCreator);
        addEntity(usa);

        changeEntity();

        btnclearContent.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                changeEntity();
            }
        });

        guessButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                playGame();
            }
        });
    }

    public void changeEntity(){
        continueGame();
    }

    public void continueGame(){
        entityId = genRandomEntityInd();
        Entity entity = entities[entityId];

        entName = entity.getName();
        entityName.setText(entName);
        userIn.getText().clear();

        ImageSetter();
        welcomeToGame(entity);
    }

    public void ImageSetter(){
        String entName = entityName.getText().toString();
        if(entName.equals("Justin Trudeau")){
            entityImage.setImageResource(R.drawable.justint);
        }
        else if(entName.equals("Celine Dion")){
            entityImage.setImageResource(R.drawable.celidion);
        }
        else if(entName.equals("My Creator")){
            entityImage.setImageResource(R.drawable.creator);
        }
        else if(entName.equals("United States")){
            entityImage.setImageResource(R.drawable.usaflag);
        }
    }

    public void welcomeToGame(Entity entity){
        AlertDialog.Builder welcomeAlert = new AlertDialog.Builder(GuessMaster.this);
        welcomeAlert.setTitle("GuessMaster Game Version 3.0");
        welcomeAlert.setMessage(entity.welcomeMessage());
        welcomeAlert.setCancelable(false);
        welcomeAlert.setNegativeButton("Start Game", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(),"Game is starting... Enjoy",Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog dialog = welcomeAlert.create();
        dialog.show();
    }

    public GuessMaster() {
        this.numberOfEntities = 0;
        this.entities = new Entity[100];
        this.tickets = 0;
    }

    public GuessMaster(int numberOfEntities, Entity entity) {
        this.numberOfEntities = numberOfEntities;
        this.entities[this.numberOfEntities] = entity;
        this.tickets = 0;
    }

    public void addEntity(Entity entity) {
        this.numberOfEntities += 1;
        this.entities[this.numberOfEntities] = entity;
    }

    public Entity getEntity(int entityInd) {
        return (this.entities[entityInd]);
    }

    public Entity findEntity(){
        String entName = entityName.getText().toString();
        Entity entity;
        if(entName.equals("Justin Trudeau")) {
            entity = trudeau;
        }
        else if(entName.equals("Celine Dion")) {
            entity = dion;
        }
        else if(entName.equals("My Creator")) {
            entity = myCreator;
        }
        else if(entName.equals("United States")) {
            entity = usa;
        }
        else {
            entity = trudeau;
        }
        return entity;
    }

    public int genRandomEntityInd() {
        Random rand = new Random();
        return rand.nextInt(this.numberOfEntities + 1);
    }

    public void playGame(Entity entity) {
        answer = userIn.getText().toString();
        answer = answer.replace("\n","").replace("\r","");
        Date dateInput = new Date(answer);

        final int awardedTickets = entity.getAwardedTicketNumber();
        AlertDialog.Builder closingAlert = new AlertDialog.Builder(GuessMaster.this);
        closingAlert.setTitle("You Won!");
        closingAlert.setMessage("BINGO!");
        closingAlert.setCancelable(false);
        closingAlert.setNegativeButton("Start Game", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(),"You won " + awardedTickets + " tickets.", Toast.LENGTH_SHORT).show();
            }
        });

        if(dateInput.equals(entity.getBorn())) {
            continueGame();
            AlertDialog dialog = closingAlert.create();
            dialog.show();
            tickets = tickets + entity.getAwardedTicketNumber();
        }
        else if(dateInput.precedes(entity.getBorn())){
            AlertDialog.Builder laterDateMessage = new AlertDialog.Builder(GuessMaster.this);
            laterDateMessage.setMessage("Enter a later date");
            AlertDialog dialog = laterDateMessage.create();
            dialog.show();
        }
        else if(entity.getBorn().precedes(dateInput)) {
            AlertDialog.Builder earlierDateMessage = new AlertDialog.Builder(GuessMaster.this);
            earlierDateMessage.setMessage("Enter a earlier date");
            AlertDialog dialog = earlierDateMessage.create();
            dialog.show();
        }
        String ticketString = Integer.toString(tickets);
        ticketsum.setText("Total Tickets: " + ticketString);
    }


    public void playGame(int entityInd) {
        Entity entity = this.getEntity(entityInd);

        answer = userIn.getText().toString();
        answer = answer.replace("\n","").replace("\r","");
        Date dateInput = new Date(answer);

        final int awardedTickets = entity.getAwardedTicketNumber();
        AlertDialog.Builder closingAlert = new AlertDialog.Builder(GuessMaster.this);
        closingAlert.setTitle("You Won!");
        closingAlert.setMessage("BINGO!");
        closingAlert.setCancelable(false);
        closingAlert.setNegativeButton("Start Game", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(),"You won " + awardedTickets + " tickets.", Toast.LENGTH_SHORT).show();
            }
        });

        if(dateInput.equals(entity.getBorn())) {
            continueGame();
            AlertDialog dialog = closingAlert.create();
            dialog.show();
            tickets = tickets + entity.getAwardedTicketNumber();
        }
        else if(dateInput.precedes(entity.getBorn())){
            AlertDialog.Builder laterDateMessage = new AlertDialog.Builder(GuessMaster.this);
            laterDateMessage.setMessage("Enter a later date");
            AlertDialog dialog = laterDateMessage.create();
            dialog.show();
        }
        else if(entity.getBorn().precedes(dateInput)) {
            AlertDialog.Builder earlierDateMessage = new AlertDialog.Builder(GuessMaster.this);
            earlierDateMessage.setMessage("Enter a earlier date");
            AlertDialog dialog = earlierDateMessage.create();
            dialog.show();
        }
        String ticketString = Integer.toString(tickets);
        ticketsum.setText("Total Tickets: " + ticketString);
    }

    public void playGame(){
        Entity entity = findEntity();

        answer = userIn.getText().toString();
        answer = answer.replace("\n","").replace("\r","");
        Date dateInput = new Date(answer);

        final int awardedTickets = entity.getAwardedTicketNumber();
        AlertDialog.Builder correctGuess = new AlertDialog.Builder(GuessMaster.this);
        correctGuess.setTitle("You Won!");
        correctGuess.setMessage("BINGO!");
        correctGuess.setCancelable(false);
        correctGuess.setNegativeButton("Start Game", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(),"You won " + awardedTickets + " tickets.", Toast.LENGTH_SHORT).show();
            }
        });

        if(dateInput.equals(entity.getBorn())) {
            continueGame();
            AlertDialog dialog = correctGuess.create();
            dialog.show();
            tickets = tickets + entity.getAwardedTicketNumber();
        }
        else if(dateInput.precedes(entity.getBorn())){
            AlertDialog.Builder incorrectEarlyGuess = new AlertDialog.Builder(GuessMaster.this);
            incorrectEarlyGuess.setMessage("Enter a later date");
            AlertDialog dialog = incorrectEarlyGuess.create();
            dialog.show();
        }
        else if(entity.getBorn().precedes(dateInput)) {
            AlertDialog.Builder incorrectLateGuess = new AlertDialog.Builder(GuessMaster.this);
            incorrectLateGuess.setMessage("Enter a earlier date");
            AlertDialog dialog = incorrectLateGuess.create();
            dialog.show();
        }
        String ticketString = Integer.toString(tickets);
        ticketsum.setText("Total Tickets: " + ticketString);
    }
}